# coding: utf-8


def test_sptk():
    assert 1 == 1
