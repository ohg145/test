.. automodule:: pysptk.synthesis
