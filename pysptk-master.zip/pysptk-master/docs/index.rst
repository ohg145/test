.. pysptk documentation master file, created by
   sphinx-quickstart on Fri Sep  4 18:38:55 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

:github_url: https://github.com/r9y9/pysptk

pysptk
======

.. automodule:: pysptk

Installation guide
------------------

.. toctree::
    :maxdepth: 2

    introduction


API documentation
-----------------

.. toctree::
    :maxdepth: 2

    api


Developer Documentation
-----------------------

.. toctree::
    :maxdepth: 2

    development


.. toctree::
    :maxdepth: 1
    :caption: Meta information

    changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
