.. automodule:: pysptk.util
