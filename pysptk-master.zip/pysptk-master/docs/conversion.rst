.. automodule:: pysptk.conversion
